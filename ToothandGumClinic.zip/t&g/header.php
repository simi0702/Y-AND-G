<!--whatsapp & call dsktop-->  
<a href="https://wa.link/oalck1" class="icon" target="_blank" style="right: 1%;bottom: 48%;    position: fixed;z-index: 9999;">
    <img src="img/wa-9.png" style="width:50px" >
</a>
<a href="tel: +91-8448822629" class="icon" target="_blank" style="right: 1%;bottom: 39%;    position: fixed;z-index: 9999;">
    <img src="img/call-9.png" style="width:49px" ></a>
</a>
<!--whatsapp & call dsktop--> 


<!--whatsapp & call dsktop--> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.icon-bar1 {
  position: fixed;
   display: -webkit-box;
	display: -webkit-flex;
	display: -ms-flexbox;
	display: flex;
	-webkit-flex-wrap: nowrap;
	-ms-flex-wrap: nowrapwrap;
	flex-wrap: nowrap;
    width: 100%;
	left: 0;
	bottom: 0;
	z-index: 2500;
}

.icon-bar1 a {
  display: block;
  text-align: center;
  padding-top: 7px;
  padding-bottom: 7px;
  transition: all 0.3s ease;
  color: white;
  font-size: 14px;
border-right: 1px solid #fff;
}

.call {
  background: #f68278;
  color: #000;
  width: 100%;
}

.whatsapp {
  background: #f68278;
  color: #000;
  width: 100%;
}
@media (min-width:1025px) { 
    .display-none {
        display: none;
    }
    
    
}
@media (min-width:1281px) { 
    
    
    .icon{
        display:block;
    }
}

@media only screen 
  and (min-device-width: 320px) 
  and (max-device-width: 480px)
  and (-webkit-min-device-pixel-ratio: 2) {
 .icon{
        display:none;
    }
}

</style>  

<div class="icon-bar1 display-none">
  <a href="tel:+91-8448822629" onClick="ga('send', 'event', { eventCategory: 'phone', eventAction: 'click', eventLabel: 'call-button'});" class="call"><i style="color: #fff; font-size:25px;" class="fa fa-phone"></i> <span style="color: #fff; font-size:15px;">Call Now</span></a> 
  <a href="https://wa.link/oalck1" onClick="ga('send', 'event', { eventCategory: 'email', eventAction: 'click', eventLabel: 'whatsapp-button'});" class="whatsapp"><i style="color: #fff; font-size:25px;" class="fa fa-whatsapp"></i> <span style="color: #fff; font-size:15px;">WhatsApp</span></a> 
</div>
<!--whatsapp & call dsktop--> 

 <link rel="shortcut icon" href="img/favicon.jpg" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow&family=Barlow+Condensed&family=Gilda+Display&display=swap">
    <link rel="stylesheet" href="css/plugins.css" />
    <link rel="stylesheet" href="css/style.css" /><!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-GMM11C13LY"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-GMM11C13LY');
</script>

<script>function loadScript(a){var b=document.getElementsByTagName("head")[0],c=document.createElement("script");c.type="text/javascript",c.src="https://tracker.metricool.com/resources/be.js",c.onreadystatechange=a,c.onload=a,b.appendChild(c)}loadScript(function(){beTracker.t({hash:"9d523aebdfc774de59c1f2fa41b9a893"})});</script>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <!-- Logo -->
            <div class="logo-wrapper navbar-brand valign">
                <a href="/">
                    <div class="logo">
                        <img src="img/logo.png" class="logo-img" alt="dental clinic in Agra" title="dental clinic in agra">
                    </div>
                </a>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="icon-bar"><i class="ti-line-double"></i></span> </button>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown"> <span class="nav-link active"> <a href="/">Home</a> </span></li>
                        
                    
                    <li class="nav-item dropdown"> <span class="nav-link"> About <i class="ti-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="about-clinic.php">About Clinic</a></li>
                            
                            <li class="dropdown-item"><a href="dr-jyoti-bhasin.php">Dr Jyoti C Bhasin</a></li>
                            <li class="dropdown-item"><a href="social-responsibility.php">Social Responsibility</a></li>
                            
                        </ul>
                    </li>
                    <li class="nav-item dropdown"> <span class="nav-link"> Treatments <i class="ti-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="pain-relief.php">Pain Relief</a></li>
                            <li class="dropdown-item"><a href="preventive-care.php">Preventive Treatment</a></li>
                            <li class="dropdown-item"><a href="cosmetic-treatment.php">Cosmetic Treatment</a></li>
                            
                            <li class="dropdown-item"><a href="teeth-replacement.php">Teeth Replacement</a></li>
                            <li class="dropdown-item"><a href="kids-dental-care-agra.php">Kids Dental Treatment</a></li>
                        </ul>
                    </li>
                     <li class="nav-item dropdown"> <span class="nav-link"> Speciality <i class="ti-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="single-sitting-root-canal-treatment-agra.php">Single Sitting RCT</a></li>
                            <li class="dropdown-item"><a href="crown-and-bridges-treatment-agra.php">Crown & Bridges</a></li>
                            <li class="dropdown-item"><a href="dental-implant-treatment-agra.php">Dental Implant</a></li>
                            <li class="dropdown-item"><a href="removable-denture-agra.php">Dentures</a></li>
                            <li class="dropdown-item"><a href="digital-smile-designing-agra.php">Digital Smile Designing</a></li>
                            <li class="dropdown-item"><a href="invisible-braces-treatment-agra.php">Invisalign</a></li>
                            <li class="dropdown-item"><a href="veneers-and-laminates-treatment-agra.php">Veneers & Laminates</a></li>
                            <li class="dropdown-item"><a href="full-mouth-rehabilitation.php">Full Mouth Rehabilitation</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="reviews.php">Review</a></li>
                    <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>
                    
                   
                    <li class="nav-item"><a class="nav-link" href="contact-us.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="FAQ.php">FAQ</a></li>
                </ul>
            </div>
        </div>
    </nav>