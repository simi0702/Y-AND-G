<div class="news2-sidebar row">
                        
                        
                       
                        <div class="col-md-12">
                            <div class="widget">
                                <div class="widget-title">
                                    <h6>Pain Relief</h6>
                                </div>
                                <ul>
                                    <li><a href="root-canal-treatment-agra.php"><i class="ti-angle-right"></i>Root Canal Treatment</a></li>
                                    <li><a href="wisdom-tooth-removal-agra.php"><i class="ti-angle-right"></i>Wisdom Tooth Removal</a></li>
                                    <li><a href="tmd.php"><i class="ti-angle-right"></i>TMD</a></li>
                                </ul>
                            </div>
                            
                            <div class="widget">
                                <div class="widget-title">
                                    <h6>Preventive Care</h6>
                                </div>
                                <ul>
                                    <li><a href="teeth-cleaning-agra.php"><i class="ti-angle-right"></i>Teeth Cleaning</a></li>
                                    <li><a href="bad-breath-treatment-agra.php"><i class="ti-angle-right"></i>Bad Breath Treatment</a></li>
                                    <li><a href="gum-treatment-agra.php"><i class="ti-angle-right"></i>Gum Treatment</a></li>
                                    <li><a href="fluoride-and-dental-sealant-treatment-agra.php"><i class="ti-angle-right"></i>Fluoride & Dental Sealents</a></li>
                                </ul>
                            </div>
                            
                            <div class="widget">
                                <div class="widget-title">
                                    <h6>Cosmetic Treatment</h6>
                                </div>
                                <ul>
                                    <li><a href="digital-smile-designing-agra.php"><i class="ti-angle-right"></i>Digital Smile Designing</a></li>
                                    <li><a href="invisible-braces-treatment-agra.php"><i class="ti-angle-right"></i>Invisalign</a></li>
                                    <li><a href="veneers-and-laminates-treatment-agra.php"><i class="ti-angle-right"></i>Veneers & Laminates</a></li>
                                     <li><a href="braces-treatment-agra.php"><i class="ti-angle-right"></i>Braces Treatment</a></li>
                                    <li><a href="smile-makeover-agra.php"><i class="ti-angle-right"></i>Smile Makeover</a></li>
                                    <li><a href="tooth-colored-fillings-agra.php"><i class="ti-angle-right"></i>Tooth-coloured fillings</a></li>
                                    <li><a href="teeth-whitening-agra.php"><i class="ti-angle-right"></i>Teeth Whitening</a></li>
                                </ul>
                            </div>
                            
                            <div class="widget">
                                <div class="widget-title">
                                    <h6>Teeth Replacement</h6>
                                </div>
                                <ul>
                                    <li><a href="dental-implant-treatment-agra.php"><i class="ti-angle-right"></i>Dental Implants</a></li>
                                    <li><a href="crown-and-bridges-treatment-agra.php"><i class="ti-angle-right"></i>Crown & Bridges</a></li>
                                    <li><a href="removable-denture-agra.php"><i class="ti-angle-right"></i>Dentures</a></li>
                                    <li><a href="full-mouth-rehabilitation.php"><i class="ti-angle-right"></i>Full Mouth Rehabilitation</a></li>
                                </ul>
                            </div>
                        </div>
                       
                    </div>